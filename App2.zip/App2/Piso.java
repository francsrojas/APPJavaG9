import App2.Libros;
import java.util.Scanner;

public class Piso {
    public static void crear_Piso(){
        System.out.println("Ingrese el piso que quiere agregar; \n");
        Scanner myobj = new Scanner(System.in);
        String piso_nueva = myobj.nextLine();
        Libros nuevo = new Libros();
        nuevo.setLibro(null, null, null, null, null, piso_nueva, null, null);

        System.out.println("Listo!");
    }
  
    public static void eliminar_Piso(){

    }

}
