import App2.Libros;
import java.util.Scanner;

public class Estante {
  public static void crear_Sec_Estante(){
      System.out.println("Ingrese la sección que quiere agregar; \n");
      Scanner scan = new Scanner(System.in);
      String seccion_nueva = scan.nextLine();
      Libros nuevo = new Libros();
      nuevo.setLibro(null, null, null, null, seccion_nueva, null, null, null);

      System.out.println("Listo!");
    }
  public static void eliminar_Est_Sec(){

    }
}
