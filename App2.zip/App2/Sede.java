import App2.Libros;
import java.util.Scanner;

public class Sede {
    public static void crear_Sede(){
        System.out.println("Ingrese la sede que quiere agregar; \n");
        Scanner myobj = new Scanner(System.in);
        String sede_nueva = myobj.nextLine();
        Libros nuevo = new Libros();
        nuevo.setLibro(null, null, null, null, null, null, null, sede_nueva);

        System.out.println("Listo!");
    }
    public static void eliminar_Sede(){

    }

}
